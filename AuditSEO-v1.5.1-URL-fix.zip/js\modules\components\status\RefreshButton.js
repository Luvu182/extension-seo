'use strict';

/**
 * Reusable button component for refreshing the page
 * 
 * @param {Object} props Component props
 * @param {string} props.text Button text, defaults to 'Làm mới trang'
 * @param {Object} props.customStyle Additional styles to apply
 * @returns {React.Element} The refresh button component
 */
export const RefreshButton = ({ text = 'Làm mới trang', customStyle = {} }) => {
  // Default button style
  const defaultStyle = {
    backgroundColor: '#2563eb',
    color: 'white',
    padding: '10px 20px',
    borderRadius: '6px',
    border: 'none',
    textDecoration: 'none',
    fontSize: '15px',
    fontWeight: 'bold',
    cursor: 'pointer',
    display: 'inline-block'
  };

  /**
   * Handles click on the refresh button
   * Reloads the current active tab and closes the popup
   */
  const handleRefreshClick = () => {
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      if (tabs && tabs[0] && tabs[0].id) {
        chrome.tabs.reload(tabs[0].id);
        // Automatically close popup after reloading the page
        window.close();
      }
    });
  };

  return React.createElement('button', {
    onClick: handleRefreshClick,
    style: { ...defaultStyle, ...customStyle }
  }, text);
};