'use strict';

// Performance tab module for SEO AI Assistant

// Import dependencies
// React is global
import { styles } from '../styles.js';
import { dataService } from '../data-service.js';
import { performanceService } from '../services/performance-service.js';
import { PerformanceScoreCard } from '../components/PerformanceScoreCard.js';
import { CoreWebVitalsDetail } from '../components/CoreWebVitalsDetail.js';
import { ServerResponseTime } from '../components/ServerResponseTime.js';
import { PerformanceRecommendations } from '../components/PerformanceRecommendations.js';

/**
 * Performance Tab Component
 * Displays performance metrics, scores, and recommendations
 * @param {Object} props - Component properties
 * @param {Object} props.pageData - Page data containing performance metrics
 * @returns {React.Element} - The Performance Tab component
 */
export const PerformanceTab = ({ pageData }) => {
    // Get data from props or use mock data if not available
    const data = pageData || dataService.mockData;

    // Get normalized metrics with defaults for missing values
    const metrics = performanceService.getNormalizedMetrics(data);

    // Calculate performance score and get evaluation
    const performanceEvaluation = performanceService.calculatePerformanceScore(metrics);

    // Generate recommendations based on metrics
    const recommendations = performanceService.generateRecommendations(metrics);

    // Render the performance tab with its components
    return React.createElement('div', { style: styles.spaceY3 },
        // Performance Summary Section
        React.createElement(PerformanceScoreCard, {
            score: performanceEvaluation.score,
            category: performanceEvaluation.category,
            description: performanceEvaluation.description,
            color: performanceEvaluation.color
        }),

        // Core Web Vitals Section
        React.createElement(CoreWebVitalsDetail, { metrics }),

        // TTFB Section
        React.createElement(ServerResponseTime, { ttfb: metrics.ttfb }),

        // Recommendations Section
        React.createElement(PerformanceRecommendations, { recommendations })
    );
};
