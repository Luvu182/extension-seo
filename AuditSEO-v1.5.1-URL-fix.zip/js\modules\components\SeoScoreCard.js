'use strict';

// Import dependencies
import { styles } from '../styles.js';
import { getScoreColor } from '../utils.js';

/**
 * Component for displaying SEO score card
 * @param {Object} data - The page data containing SEO score information
 * @returns {React.Element} - The SEO score card component
 */
export const SeoScoreCard = ({ data }) => {
    // Calculate factor scores or use from data
    // If factorScores is provided, use it directly
    // Otherwise, use individual scores if available or fall back to calculated scores
    const factorScores = data.factorScores || {
        'Content Quality': {
            score: data.contentScore || (data.contentQualityScore ? data.contentQualityScore : 75),
            weight: 0.25
        },
        'Technical SEO': {
            score: data.technicalScore || (data.technicalSeoScore ? data.technicalSeoScore : 80),
            weight: 0.25
        },
        'User Experience': {
            score: data.uxScore || (data.userExperienceScore ? data.userExperienceScore : 70),
            weight: 0.2
        },
        'Mobile Optimization': {
            score: data.mobileScore || (data.mobileOptimizationScore ? data.mobileOptimizationScore : 85),
            weight: 0.15
        },
        'Link Profile': {
            score: data.linkScore || (data.linkProfileScore ? data.linkProfileScore : 65),
            weight: 0.15
        }
    };

    // Calculate overall score
    const overallScore = data.seoScore || Math.round(
        Object.values(factorScores).reduce((sum, factor) => sum + factor.score * factor.weight, 0)
    );

    // Get score color based on value
    const scoreColor = getScoreColor(overallScore);

    // Render the SEO score card
    return React.createElement('div', { style: styles.cardSection },
        React.createElement('div', { style: styles.cardTitle }, 'Overall SEO Score'),
        React.createElement('div', { style: { display: 'flex', alignItems: 'flex-start', gap: '16px' } },
            // Factors Breakdown
            React.createElement('div', { style: { flex: '7', minWidth: '0' } },
                Object.entries(factorScores).map(([factor, factorData]) =>
                    React.createElement('div', { key: factor, style: { marginBottom: '8px' } },
                        React.createElement('div', { style: { fontSize: '0.75rem', color: '#9ca3af', marginBottom: '4px' } }, factor),
                        React.createElement('div', { style: styles.progressBar },
                            React.createElement('div', {
                                style: {
                                    ...styles.progressBarFill,
                                    width: `${factorData.score}%`,
                                    backgroundColor: getScoreColor(factorData.score)
                                }
                            })
                        ),
                        React.createElement('div', { style: { display: 'flex', justifyContent: 'space-between', fontSize: '0.7rem', color: '#9ca3af', marginTop: '2px' } },
                            React.createElement('span', null, `${factorData.score}/100`),
                            React.createElement('span', null, `Weight: ${Math.round(factorData.weight * 100)}%`)
                        )
                    )
                )
            ),
            // Overall Score Circle
            React.createElement('div', { style: { flex: '3', display: 'flex', justifyContent: 'center', alignItems: 'center' } },
                React.createElement('div', {
                    style: {
                        width: '100px',
                        height: '100px',
                        borderRadius: '50%',
                        border: `3px solid ${scoreColor}`,
                        display: 'flex',
                        justifyContent: 'center',
                        alignItems: 'center',
                        fontSize: '1.8rem',
                        fontWeight: '700',
                        color: scoreColor
                    }
                }, overallScore)
            )
        )
    );
};
