'use strict';

// Import dependencies
import { styles } from '../styles.js';

/**
 * Component to render a performance metric with progress bar
 * @param {Object} props - Component properties
 * @param {string} props.label - Metric label
 * @param {string} props.value - Metric value
 * @param {string} props.color - Color for the metric
 * @param {number} props.percentage - Percentage for progress bar
 * @param {string} props.description - Optional description of the metric
 * @returns {React.Element} - The MetricItem component
 */
export const MetricItem = ({ label, value, color, percentage, description }) => {
    return React.createElement('div', { style: { marginBottom: '10px' } },
        React.createElement('div', { style: { display: 'flex', justifyContent: 'space-between', fontSize: '0.75rem', marginBottom: '4px' } },
            React.createElement('span', { style: { color: '#e2e8f0' } }, label),
            React.createElement('span', { style: { color: color } }, value)
        ),
        React.createElement('div', { style: styles.progressBar },
            React.createElement('div', { style: { ...styles.progressFill, backgroundColor: color, width: `${percentage}%` } })
        ),
        description && React.createElement('div', { style: { fontSize: '0.7rem', color: '#cbd5e1', marginTop: '4px', lineHeight: '1.2' } }, description)
    );
};
