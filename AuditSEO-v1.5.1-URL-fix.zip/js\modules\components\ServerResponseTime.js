'use strict';

// Import dependencies
import { styles } from '../styles.js';
import { MetricItem } from './MetricItem.js';
import { performanceService } from '../services/performance-service.js';

/**
 * Component to display server response time metrics
 * @param {Object} props - Component properties
 * @param {number} props.ttfb - Time to First Byte value
 * @returns {React.Element} - The ServerResponseTime component
 */
export const ServerResponseTime = ({ ttfb }) => {
    const ttfbEvaluation = performanceService.evaluateTTFB(ttfb);
    
    return React.createElement('div', { style: styles.cardSection },
        React.createElement('div', { style: styles.cardTitle }, 'Server Response Time'),
        React.createElement(MetricItem, {
            label: 'TTFB (Time to First Byte)',
            value: `${ttfb}s`,
            color: ttfbEvaluation.color,
            percentage: ttfbEvaluation.percentage,
            description: 'Time for the browser to receive the first byte from the server. Lower is better.'
        }),
        React.createElement('div', { 
            style: { 
                fontSize: '0.8rem', 
                marginTop: '8px', 
                lineHeight: '1.3', 
                color: '#e2e8f0' 
            } 
        }, ttfbEvaluation.evaluation)
    );
};
