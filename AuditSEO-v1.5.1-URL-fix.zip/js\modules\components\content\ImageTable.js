'use strict';

/**
 * ImageTable - Displays a table of images with details
 * 
 * @param {Object} props - Component props
 * @param {Array} props.images - Array of image objects to display
 * @returns {React.Element} Rendered component
 */
export const ImageTable = React.memo(({ images }) => {
    // Helper function to get size text
    const getSizeText = (width, height) => {
        if (width && height) {
            return `${width}×${height}`;
        }
        return 'Unknown';
    };
    
    // Helper function to get file size text
    const getFileSizeText = (fileSize) => {
        if (fileSize === null || fileSize === undefined) return 'Unknown';
        if (fileSize < 1024) {
            return `${fileSize} KB`;
        } else {
            return `${(fileSize / 1024).toFixed(1)} MB`;
        }
    };
    
    // Create a thumbnail style for image previews
    const thumbnailStyle = {
        maxWidth: '50px',
        maxHeight: '50px',
        border: '1px solid #e2e8f0',
        borderRadius: '4px',
        objectFit: 'contain',
        backgroundColor: '#f8fafc'
    };
    
    return React.createElement('div', { 
        style: { 
            backgroundColor: '#f8fafc', 
            borderRadius: '6px', 
            padding: '12px',
            marginTop: '16px' 
        } 
    },
        React.createElement('div', { 
            style: { 
                fontSize: '0.85rem', 
                fontWeight: '600', 
                marginBottom: '8px', 
                color: '#64748b' 
            } 
        }, 'All Images'),
        React.createElement('div', { 
            style: { 
                maxHeight: '400px', 
                overflowY: 'auto' 
            } 
        },
            React.createElement('table', { 
                style: { 
                    width: '100%', 
                    borderCollapse: 'collapse', 
                    fontSize: '0.8rem' 
                } 
            },
                React.createElement('thead', { 
                    style: { 
                        position: 'sticky', 
                        top: 0, 
                        backgroundColor: '#f8fafc',
                        zIndex: 1
                    } 
                },
                    React.createElement('tr', null,
                        React.createElement('th', { 
                            style: { 
                                textAlign: 'center', 
                                padding: '6px', 
                                borderBottom: '1px solid #cbd5e1', 
                                color: '#475569',
                                width: '60px'
                            } 
                        }, 'Preview'),
                        React.createElement('th', { 
                            style: { 
                                textAlign: 'left', 
                                padding: '6px', 
                                borderBottom: '1px solid #cbd5e1', 
                                color: '#475569',
                                width: '30%'
                            } 
                        }, 'Filename'),
                        React.createElement('th', { 
                            style: { 
                                textAlign: 'left', 
                                padding: '6px', 
                                borderBottom: '1px solid #cbd5e1', 
                                color: '#475569',
                                width: '30%'
                            } 
                        }, 'Alt Text'),
                        React.createElement('th', { 
                            style: { 
                                textAlign: 'left', 
                                padding: '6px', 
                                borderBottom: '1px solid #cbd5e1', 
                                color: '#475569',
                                width: '15%'
                            } 
                        }, 'Dimensions'),
                        React.createElement('th', { 
                            style: { 
                                textAlign: 'left', 
                                padding: '6px', 
                                borderBottom: '1px solid #cbd5e1', 
                                color: '#475569',
                                width: '15%'
                            } 
                        }, 'File Size')
                    )
                ),
                
                React.createElement('tbody', null,
                    images.map((img, index) => {
                        const filename = img.filename || (img.src ? img.src.split('/').pop() : 'Unknown');
                        const altText = img.alt || 'Missing alt text';
                        const dimensions = getSizeText(img.width, img.height);
                        const fileSize = getFileSizeText(img.fileSize);
                        
                        return React.createElement('tr', { key: index },
                            // Column 1: Preview Image
                            React.createElement('td', { 
                                style: { 
                                    padding: '6px', 
                                    borderBottom: '1px solid #e2e8f0',
                                    textAlign: 'center'
                                } 
                            },
                                React.createElement('img', {
                                    src: img.src,
                                    alt: 'Preview',
                                    style: thumbnailStyle,
                                    onError: (e) => {
                                        e.target.onerror = null;
                                        e.target.src = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="50" height="50" viewBox="0 0 24 24" fill="none" stroke="%23CBD5E1" stroke-width="1" stroke-linecap="round" stroke-linejoin="round"%3E%3Crect x="3" y="3" width="18" height="18" rx="2" ry="2"%3E%3C/rect%3E%3Ccircle cx="8.5" cy="8.5" r="1.5"%3E%3C/circle%3E%3Cpolyline points="21 15 16 10 5 21"%3E%3C/polyline%3E%3C/svg%3E';
                                    }
                                })
                            ),
                            // Column 2: Filename (with truncate & tooltip)
                            React.createElement('td', { 
                                style: { 
                                    padding: '6px', 
                                    borderBottom: '1px solid #e2e8f0', 
                                    color: img.hasNonOptimizedFilename ? '#f59e0b' : '#4b5563',
                                    maxWidth: '0', // Needed for text-overflow to work with flexbox
                                    overflow: 'hidden'
                                },
                                title: filename
                            },
                                React.createElement('div', {
                                    style: {
                                        maxHeight: '3.6em', // Approx 3 lines
                                        overflow: 'hidden',
                                        textOverflow: 'ellipsis',
                                        display: '-webkit-box',
                                        WebkitLineClamp: 3,
                                        WebkitBoxOrient: 'vertical'
                                    }
                                }, filename)
                            ),
                            // Column 3: Alt Text (with truncate & tooltip)
                            React.createElement('td', { 
                                style: { 
                                    padding: '6px', 
                                    borderBottom: '1px solid #e2e8f0', 
                                    color: img.alt ? '#4b5563' : '#ef4444',
                                    fontStyle: img.alt ? 'normal' : 'italic',
                                    maxWidth: '0', // Needed for text-overflow to work with flexbox
                                    overflow: 'hidden'
                                },
                                title: altText
                            },
                                React.createElement('div', {
                                    style: {
                                        maxHeight: '3.6em', // Approx 3 lines
                                        overflow: 'hidden',
                                        textOverflow: 'ellipsis',
                                        display: '-webkit-box',
                                        WebkitLineClamp: 3,
                                        WebkitBoxOrient: 'vertical'
                                    }
                                }, altText)
                            ),
                            // Column 4: Dimensions
                            React.createElement('td', { 
                                style: { 
                                    padding: '6px', 
                                    borderBottom: '1px solid #e2e8f0', 
                                    color: '#4b5563' 
                                } 
                            }, dimensions),
                            // Column 5: File Size
                            React.createElement('td', { 
                                style: { 
                                    padding: '6px', 
                                    borderBottom: '1px solid #e2e8f0', 
                                    color: '#4b5563' 
                                } 
                            }, fileSize)
                        );
                    })
                )
            )
        )
    );
});