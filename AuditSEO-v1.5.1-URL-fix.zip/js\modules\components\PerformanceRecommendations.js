'use strict';

// Import dependencies
import { styles } from '../styles.js';

/**
 * Component to display performance recommendations
 * @param {Object} props - Component properties
 * @param {Array} props.recommendations - List of recommendations
 * @returns {React.Element} - The PerformanceRecommendations component
 */
export const PerformanceRecommendations = ({ recommendations }) => {
    return React.createElement('div', { style: styles.cardSection },
        React.createElement('div', { style: styles.cardTitle }, 'Performance Recommendations'),
        React.createElement('div', null,
            recommendations.map((rec, index) =>
                React.createElement('div', { 
                    key: index, 
                    style: { 
                        borderLeft: `3px solid ${rec.priority === 'high' ? '#ef4444' : rec.priority === 'medium' ? '#f59e0b' : '#3b82f6'}`, 
                        paddingLeft: '12px', 
                        marginBottom: '16px' 
                    } 
                },
                    React.createElement('div', { 
                        style: { 
                            fontSize: '0.9rem', 
                            fontWeight: '600', 
                            marginBottom: '4px', 
                            color: '#f1f5f9' 
                        } 
                    }, rec.title),
                    React.createElement('div', { 
                        style: { 
                            fontSize: '0.8rem', 
                            color: '#cbd5e1', 
                            lineHeight: '1.3' 
                        } 
                    }, rec.description)
                )
            )
        )
    );
};
