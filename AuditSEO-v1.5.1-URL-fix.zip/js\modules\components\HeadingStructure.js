'use strict';

/**
 * HeadingStructure Component - Displays a website's heading structure with filtering options
 * @param {Object} props - Component props
 * @param {Object} props.pageData - The page data containing heading information
 * @returns {React.Element} Rendered component
 */
export const HeadingStructure = ({ pageData }) => {
    // State for heading filters
    const [activeFilters, setActiveFilters] = React.useState({
        h1: true,
        h2: true,
        h3: true,
        h4: true,
        h5: true
    });

    // Process headings to have a consistent structure and preserve document order
    const processHeadings = () => {
        let headingsArray = [];
        
        if (pageData.content?.headings) {
            // If we already have an array of objects with level and text
            headingsArray = [...pageData.content.headings];
        } else if (pageData.headings) {
            // Old format with headings categorized by level
            // Create position index to track original position in document
            let position = 0;
            
            // Process each heading type in order h1-h6
            ['h1', 'h2', 'h3', 'h4', 'h5', 'h6'].forEach(level => {
                if (pageData.headings[level] && Array.isArray(pageData.headings[level])) {
                    // For each heading text of this level, create a heading object
                    pageData.headings[level].forEach(text => {
                        headingsArray.push({
                            level: parseInt(level.substring(1)),
                            text,
                            position: position++
                        });
                    });
                }
            });

            // This is a best effort to reconstruct document order
            // If the headings were already collected in document order,
            // we use the position property to sort them
            if (headingsArray.some(h => h.position !== undefined)) {
                headingsArray.sort((a, b) => a.position - b.position);
            }
        }
        
        return headingsArray;
    };

    // Get all headings in document order
    const headingsInDocumentOrder = processHeadings();

    // Toggle a heading level filter
    const toggleFilter = (level) => {
        setActiveFilters(prev => ({
            ...prev,
            [level]: !prev[level]
        }));
    };

    // Filter headings based on active filters
    const filteredHeadings = headingsInDocumentOrder.filter(heading => 
        activeFilters[`h${heading.level}`]
    );

    // Check for heading structure issues
    const h1Count = headingsInDocumentOrder.filter(h => h.level === 1).length;
    
    // Detect if there are any LOWER LEVEL headings before the first H1
    // This means we only care about H2-H6 appearing before H1, not ANY heading
    const hasLowerHeadingsBeforeH1 = (() => {
        if (headingsInDocumentOrder.length === 0) return false;
        
        // Find the index of the first H1
        const firstH1Index = headingsInDocumentOrder.findIndex(h => h.level === 1);
        
        // If there's no H1, then we can't have lower headings before H1
        if (firstH1Index === -1) return false;
        
        // Check if there are any lower level headings (level > 1) before the first H1
        for (let i = 0; i < firstH1Index; i++) {
            // If we find any heading with level > 1 before the first H1, that's an issue
            if (headingsInDocumentOrder[i].level > 1) {
                return true;
            }
        }
        
        // No lower level headings found before the first H1
        return false;
    })();
    
    // Helper to check if heading levels are skipped and identify which ones
    const checkForSkippedHeadingLevels = (headings) => {
        let skippedInfo = { skipped: false, details: [] };
        let currentLevel = 0;
        
        for (let i = 0; i < headings.length; i++) {
            const heading = headings[i];
            if (i === 0) {
                currentLevel = heading.level;
                continue;
            }
            
            if (heading.level > currentLevel) {
                if (heading.level > currentLevel + 1) {
                    // Found a skip - e.g., from H2 to H4 (skipping H3)
                    skippedInfo.skipped = true;
                    skippedInfo.details.push({
                        from: currentLevel,
                        to: heading.level,
                        text: heading.text,
                        position: i
                    });
                }
                currentLevel = heading.level;
            } else {
                currentLevel = heading.level;
            }
        }
        
        return skippedInfo;
    };
    
    const skippedLevelsInfo = checkForSkippedHeadingLevels(headingsInDocumentOrder);
    const hasSkippedLevels = skippedLevelsInfo.skipped;
    const showHeadingIssues = h1Count !== 1 || hasLowerHeadingsBeforeH1 || hasSkippedLevels;

    // Render the filter controls
    const renderFilterControls = () => {
        return React.createElement('div', { 
            style: { 
                display: 'flex', 
                gap: '8px',
                marginBottom: '12px',
                flexWrap: 'wrap'
            } 
        },
            ['h1', 'h2', 'h3', 'h4', 'h5'].map(level => 
                React.createElement('button', {
                    key: level,
                    onClick: () => toggleFilter(level),
                    style: {
                        backgroundColor: activeFilters[level] ? '#3b82f6' : '#475569',
                        color: 'white',
                        border: 'none',
                        borderRadius: '4px',
                        padding: '4px 8px',
                        fontSize: '0.75rem',
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '4px',
                        transition: 'background-color 0.2s'
                    }
                },
                    // Checkbox icon
                    React.createElement('span', {
                        style: {
                            display: 'inline-block',
                            width: '12px',
                            height: '12px',
                            borderRadius: '2px',
                            border: '1px solid white',
                            backgroundColor: activeFilters[level] ? 'white' : 'transparent',
                            position: 'relative'
                        }
                    },
                        activeFilters[level] && React.createElement('span', {
                            style: {
                                position: 'absolute',
                                top: '1px',
                                left: '3px',
                                width: '6px',
                                height: '6px',
                                backgroundColor: '#3b82f6'
                            }
                        })
                    ),
                    level.toUpperCase()
                )
            )
        );
    };

    // Render content with headings
    return React.createElement('div', { style: { marginTop: '8px' } },
        // Heading filters
        renderFilterControls(),
        
        // Heading list
        filteredHeadings.length === 0
            ? React.createElement('div', { 
                style: { 
                    padding: '12px', 
                    textAlign: 'center', 
                    color: '#e2e8f0', 
                    fontSize: '0.9rem' 
                } 
            }, 'No headings match the current filters.')
            : React.createElement('div', { style: { marginTop: '8px' } },
                filteredHeadings.map((heading, index) =>
                    React.createElement('div', { 
                        key: index, 
                        style: { 
                            marginBottom: '8px', 
                            paddingLeft: `${(heading.level - 1) * 16}px`, 
                            borderLeft: heading.level === 1 ? '3px solid #3b82f6' : 'none', 
                            paddingTop: heading.level === 1 ? '4px' : '0', 
                            paddingBottom: heading.level === 1 ? '4px' : '0' 
                        } 
                    },
                        React.createElement('span', { 
                            style: { 
                                fontWeight: '600', 
                                color: '#94a3b8', 
                                marginRight: '6px' 
                            } 
                        }, `H${heading.level}`),
                        React.createElement('span', { 
                            style: { 
                                fontSize: '0.9rem', 
                                fontWeight: heading.level <= 2 ? '500' : '400', 
                                color: heading.level === 1 ? '#60a5fa' : '#f1f5f9' 
                            } 
                        }, heading.text)
                    )
                )
            ),
        
        // Heading structure issues
        showHeadingIssues && React.createElement('div', { 
            style: { 
                marginTop: '16px', 
                padding: '12px', 
                backgroundColor: '#fff9ed', 
                borderRadius: '6px', 
                borderLeft: '3px solid #f59e0b' 
            } 
        },
            React.createElement('div', { 
                style: { 
                    fontSize: '0.85rem', 
                    fontWeight: '600', 
                    marginBottom: '8px', 
                    color: '#9a3412' 
                } 
            }, 'Heading Structure Issues:'),
            React.createElement('ul', { 
                style: { 
                    marginLeft: '16px', 
                    marginBottom: '0', 
                    fontSize: '0.8rem', 
                    color: '#4b5563' 
                } 
            },
                h1Count === 0 && React.createElement('li', { 
                    style: { marginBottom: '4px' } 
                }, 'No H1 heading found.'),
                h1Count > 1 && React.createElement('li', { 
                    style: { marginBottom: '4px' } 
                }, `Found ${h1Count} H1 headings. Use only one.`),
                hasLowerHeadingsBeforeH1 && React.createElement('li', { 
                    style: { marginBottom: '4px' } 
                }, 'Lower-level headings (H2-H6) found before the first H1. For better SEO structure, H1 should appear before any lower level headings.'),
                hasSkippedLevels && React.createElement('li', { 
                    style: { marginBottom: '4px' } 
                }, 
                    React.createElement(React.Fragment, null,
                        'Heading levels skipped: ',
                        skippedLevelsInfo.details.length > 0 && 
                            React.createElement('ul', { style: { marginTop: '4px', marginLeft: '16px' } },
                                skippedLevelsInfo.details.slice(0, 3).map((detail, idx) => 
                                    React.createElement('li', { key: idx, style: { fontSize: '0.75rem' } },
                                        `From H${detail.from} to H${detail.to} (skipping ${Array.from({length: detail.to - detail.from - 1}, (_, i) => `H${detail.from + i + 1}`).join(', ')}) at "${detail.text.substring(0, 30)}${detail.text.length > 30 ? '...' : ''}"`
                                    )
                                ),
                                skippedLevelsInfo.details.length > 3 && 
                                    React.createElement('li', { style: { fontSize: '0.75rem' } },
                                        `...and ${skippedLevelsInfo.details.length - 3} more instances`
                                    )
                            )
                    )
                )
            )
        )
    );
};
