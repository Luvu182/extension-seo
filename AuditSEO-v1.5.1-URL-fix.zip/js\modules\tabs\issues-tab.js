'use strict';

// Issues tab module for SEO AI Assistant

// Import dependencies
// React is global
import { styles } from '../styles.js';
import { dataService } from '../data-service.js';

// Helper component for Issue Bar
const IssueBar = ({ label, count, total, color }) => {
    const percentage = total > 0 ? (count / total) * 100 : 0;
    // Use React.createElement
    return React.createElement('div', { style: { display: 'flex', flexDirection: 'column', gap: '4px' } },
        React.createElement('div', { style: { display: 'flex', justifyContent: 'space-between', fontSize: '0.8rem', color: '#f1f5f9' } },
            React.createElement('div', null, label),
            React.createElement('div', { style: { fontWeight: '500' } }, count.toString())
        ),
        React.createElement('div', { style: { height: '8px', width: '100%', backgroundColor: '#475569', borderRadius: '4px', overflow: 'hidden' } },
            React.createElement('div', { style: { height: '100%', width: `${percentage}%`, backgroundColor: color, borderRadius: '4px' } })
        )
    );
};

// Helper component for Issue Item
const IssueItem = ({ issue, index, color }) => {
    // Use React.createElement
    return React.createElement('div', { style: { padding: '12px', backgroundColor: '#f8fafc', borderRadius: '6px', borderLeft: `3px solid ${color}` } },
        React.createElement('div', { style: { display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' } },
            React.createElement('div', { style: { width: '20px', height: '20px', borderRadius: '50%', backgroundColor: color, color: 'white', fontSize: '0.75rem', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: '600' } }, (index + 1).toString()),
            React.createElement('div', { style: { fontSize: '0.9rem', fontWeight: '600', color: '#1e293b' } }, issue.message || 'Unknown issue')
        ),
        issue.description && React.createElement('div', { style: { fontSize: '0.85rem', lineHeight: '1.4', color: '#475569', marginBottom: '8px' } }, issue.description),
        issue.location && React.createElement('div', { style: { fontSize: '0.8rem', color: '#64748b', backgroundColor: '#f1f5f9', padding: '6px 8px', borderRadius: '4px', fontFamily: 'monospace' } }, issue.location),
        issue.recommendation && React.createElement(React.Fragment, null,
            React.createElement('div', { style: { fontSize: '0.8rem', fontWeight: '600', marginTop: '8px', marginBottom: '4px', color: '#475569' } }, 'Recommendation:'),
            React.createElement('div', { style: { fontSize: '0.85rem', lineHeight: '1.4', color: '#475569' } }, issue.recommendation)
        )
    );
};

// Main Component
export const IssuesTab = ({ pageData }) => {
    const data = pageData || dataService.mockData;
    const issuesData = data.issues || { critical: [], warnings: [], suggestions: [] };
    const criticalIssues = issuesData.critical || [];
    const warningIssues = issuesData.warnings || [];
    const suggestionIssues = issuesData.suggestions || [];
    const totalIssues = criticalIssues.length + warningIssues.length + suggestionIssues.length;

    let statusIconChar = '✅';
    let statusBgColor = '#dcfce7';
    let statusIconBgColor = '#a7f3d0';
    let statusTitleColor = '#047857';
    let statusDescription = 'Your page looks great! No issues detected.';

    if (criticalIssues.length > 0) {
        statusIconChar = '❌'; statusBgColor = '#fee2e2'; statusIconBgColor = '#fecaca'; statusTitleColor = '#b91c1c';
        statusDescription = `${criticalIssues.length} critical issue(s) need attention`;
        if (warningIssues.length > 0 || suggestionIssues.length > 0) statusDescription += ` plus ${warningIssues.length + suggestionIssues.length} other issue(s)`;
    } else if (warningIssues.length > 0) {
        statusIconChar = '⚠️'; statusBgColor = '#fff7ed'; statusIconBgColor = '#fed7aa'; statusTitleColor = '#c2410c';
        statusDescription = `${warningIssues.length} warning(s)`;
        if (suggestionIssues.length > 0) statusDescription += ` and ${suggestionIssues.length} suggestion(s)`;
    } else if (suggestionIssues.length > 0) {
        statusIconChar = 'ℹ️'; statusBgColor = '#dbeafe'; statusIconBgColor = '#bfdbfe'; statusTitleColor = '#1e40af';
        statusDescription = `${suggestionIssues.length} suggestion(s) for improvement`;
    }

    // Use React.createElement
    return React.createElement('div', { style: styles.spaceY3 },
        // Issues Summary Section
        React.createElement('div', { style: styles.cardSection },
            React.createElement('div', { style: styles.cardTitle }, 'Issues Summary'),
            React.createElement('div', { style: { display: 'flex', flexDirection: 'column', gap: '16px' } },
                // Overall Status
                React.createElement('div', { style: { display: 'flex', alignItems: 'center', gap: '12px', padding: '12px', backgroundColor: statusBgColor, borderRadius: '6px', borderLeft: `3px solid ${statusTitleColor}` } },
                    React.createElement('div', { style: { width: '32px', height: '32px', borderRadius: '50%', backgroundColor: statusIconBgColor, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.2rem' } }, statusIconChar),
                    React.createElement('div', { style: { display: 'flex', flexDirection: 'column' } },
                        React.createElement('div', { style: { fontSize: '0.95rem', fontWeight: '600', color: statusTitleColor } }, totalIssues === 0 ? 'No issues found!' : `Found ${totalIssues} issue${totalIssues !== 1 ? 's' : ''}`),
                        React.createElement('div', { style: { fontSize: '0.85rem', color: '#4b5563' } }, statusDescription)
                    )
                ),
                // Summary Chart (if issues exist)
                totalIssues > 0 && React.createElement('div', { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: '8px' } },
                    React.createElement('div', { style: { flex: '1', display: 'flex', flexDirection: 'column', gap: '8px' } },
                        criticalIssues.length > 0 && React.createElement(IssueBar, { label: 'Critical', count: criticalIssues.length, total: totalIssues, color: '#ef4444' }),
                        warningIssues.length > 0 && React.createElement(IssueBar, { label: 'Warnings', count: warningIssues.length, total: totalIssues, color: '#f59e0b' }),
                        suggestionIssues.length > 0 && React.createElement(IssueBar, { label: 'Suggestions', count: suggestionIssues.length, total: totalIssues, color: '#3b82f6' })
                    )
                )
            )
        ),
        // Critical Issues Section
        criticalIssues.length > 0 && React.createElement('div', { style: styles.cardSection },
            React.createElement('div', { style: { ...styles.cardTitle, color: '#ef4444' } }, 'Critical Issues'),
            React.createElement('div', { style: { display: 'flex', flexDirection: 'column', gap: '12px', marginTop: '8px' } },
                criticalIssues.map((issue, index) => React.createElement(IssueItem, { key: `crit-${index}`, issue: issue, index: index, color: '#ef4444' }))
            )
        ),
        // Warnings Section
        warningIssues.length > 0 && React.createElement('div', { style: styles.cardSection },
            React.createElement('div', { style: { ...styles.cardTitle, color: '#f59e0b' } }, 'Warnings'),
            React.createElement('div', { style: { display: 'flex', flexDirection: 'column', gap: '12px', marginTop: '8px' } },
                warningIssues.map((issue, index) => React.createElement(IssueItem, { key: `warn-${index}`, issue: issue, index: index, color: '#f59e0b' }))
            )
        ),
        // Suggestions Section
        suggestionIssues.length > 0 && React.createElement('div', { style: styles.cardSection },
            React.createElement('div', { style: { ...styles.cardTitle, color: '#3b82f6' } }, 'Suggestions'),
            React.createElement('div', { style: { display: 'flex', flexDirection: 'column', gap: '12px', marginTop: '8px' } },
                suggestionIssues.map((issue, index) => React.createElement(IssueItem, { key: `sugg-${index}`, issue: issue, index: index, color: '#3b82f6' }))
            )
        )
    );
};

// No IIFE needed
