'use strict';

// Import dependencies
import { styles } from '../styles.js';

/**
 * Component to display performance score summary
 * @param {Object} props - Component properties
 * @param {number} props.score - Performance score
 * @param {string} props.category - Performance category
 * @param {string} props.description - Performance description
 * @param {string} props.color - Score color
 * @returns {React.Element} - The PerformanceScoreCard component
 */
export const PerformanceScoreCard = ({ score, category, description, color }) => {
    return React.createElement('div', { style: styles.cardSection },
        React.createElement('div', { style: styles.cardTitle }, 'Performance Summary'),
        React.createElement('div', { style: styles.scoreContainer },
            React.createElement('div', { style: { ...styles.scoreCircle, backgroundColor: color } },
                React.createElement('div', { style: styles.scoreText },
                    React.createElement('span', { style: styles.scoreValue }, score.toString()),
                    React.createElement('span', { style: styles.scoreLabel }, 'SPEED SCORE')
                )
            )
        ),
        React.createElement('div', { style: { fontSize: '1rem', fontWeight: '600', marginBottom: '8px', color: color } }, `Performance: ${category}`),
        React.createElement('div', { style: { marginTop: '12px', fontSize: '0.9rem', lineHeight: '1.4', color: '#e2e8f0' } }, description)
    );
};
