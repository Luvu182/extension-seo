'use strict';

import { styles } from '../../styles.js';
import { StatItem } from '../common/StatItem.js';
import { ImageAnalysisService } from '../../tabs/content-tab.js';
import { ImageIssueCard } from '../content/ImageIssueCard.js';
import { ImageTable } from '../content/ImageTable.js';

/**
 * ImageContentTab - Displays image content analysis
 * 
 * @param {Object} props - Component props
 * @param {Object} props.data - Page data to analyze
 * @param {boolean} props.includeHeaderFooter - Whether to include header/footer images
 * @param {Function} props.toggleHeaderFooter - Function to toggle header/footer inclusion
 * @returns {React.Element} Rendered component
 */
export const ImageContentTab = React.memo(({ data, includeHeaderFooter, toggleHeaderFooter }) => {
    // Get the appropriate image data based on includeHeaderFooter state
    let images;
    let imageStats;
    
    if (includeHeaderFooter) {
        images = Array.isArray(data.images) ? data.images : [];
        imageStats = data.imageStats || {
            total: images.length,
            withAlt: 0,
            withoutAlt: 0,
            nonOptimizedFilenames: 0
        };
    } else {
        images = Array.isArray(data.contentOnlyImages) ? data.contentOnlyImages : [];
        imageStats = (data.imageStats && data.imageStats.contentOnly) || {
            total: images.length,
            withAlt: 0,
            withoutAlt: 0
        };
    }
    
    const hasImages = images.length > 0;
    const missingAltTextCount = imageStats.withoutAlt || 0;
    const nonOptimizedFilenamesCount = imageStats.nonOptimizedFilenames || 
        (hasImages ? images.filter(img => img.hasNonOptimizedFilename).length : 0);
    
    // Get missing alt text images
    const missingAltTextImages = hasImages ? images.filter(img => !img.alt && !img.hasAlt) : [];
    
    // Get non-optimized filename images
    const nonOptimizedFilenameImages = hasImages ? images.filter(img => img.hasNonOptimizedFilename) : [];
    
    // Toggle button style
    const toggleButtonStyle = {
        padding: '6px 12px',
        backgroundColor: includeHeaderFooter ? '#3b82f6' : '#475569',
        color: 'white',
        border: 'none',
        borderRadius: '4px',
        cursor: 'pointer',
        fontSize: '0.75rem',
        display: 'flex',
        alignItems: 'center',
        marginBottom: '16px',
        transition: 'background-color 0.2s'
    };
    
    // Toggle indicator style
    const toggleIndicatorStyle = {
        width: '12px',
        height: '12px',
        borderRadius: '50%',
        backgroundColor: includeHeaderFooter ? '#3b82f6' : 'white',
        border: '1px solid white',
        display: 'inline-block',
        marginRight: '8px'
    };

    return React.createElement(React.Fragment, null,
        // Image Analysis Section
        React.createElement('div', { style: styles.cardSection },
            React.createElement('div', { style: styles.cardTitle }, 'Image Analysis'),
            
            // Toggle button for header/footer inclusion
            React.createElement('button', { 
                onClick: toggleHeaderFooter,
                style: toggleButtonStyle
            },
                React.createElement('div', { style: toggleIndicatorStyle }),
                includeHeaderFooter ? 'Include header, footer & nav images' : 'Content images only'
            ),
            
            // Image Stats
            React.createElement('div', { style: styles.gridStats },
                React.createElement(StatItem, { 
                    label: 'Total Images', 
                    value: hasImages ? images.length.toString() : '0' 
                }),
                React.createElement(StatItem, { 
                    label: 'Missing Alt Text', 
                    value: `${missingAltTextCount} (${hasImages ? Math.round((missingAltTextCount / images.length) * 100) : 0}%)`, 
                    indicatorColor: missingAltTextCount > 0 ? '#ef4444' : '#10b981'
                }),
                React.createElement(StatItem, { 
                    label: 'Non-Optimized Filenames', 
                    value: `${nonOptimizedFilenamesCount} (${hasImages ? Math.round((nonOptimizedFilenamesCount / images.length) * 100) : 0}%)`, 
                    indicatorColor: nonOptimizedFilenamesCount > 0 ? '#f59e0b' : '#10b981'
                })
            ),
            
            // Image Issues
            (missingAltTextCount > 0 || nonOptimizedFilenamesCount > 0) && 
            React.createElement('div', { style: { marginTop: '16px' } },
                // Missing Alt Text Issues
                missingAltTextCount > 0 && React.createElement(ImageIssueCard, {
                    issueType: 'missing-alt',
                    count: missingAltTextCount,
                    images: missingAltTextImages.slice(0, 3),
                    totalCount: missingAltTextImages.length
                }),

                // Non-Optimized Filename Issues
                nonOptimizedFilenamesCount > 0 && React.createElement(ImageIssueCard, {
                    issueType: 'non-optimized-filename',
                    count: nonOptimizedFilenamesCount,
                    images: nonOptimizedFilenameImages.slice(0, 3),
                    totalCount: nonOptimizedFilenameImages.length
                })
            ),
            
            // All Images Table or Empty State
            hasImages 
                ? React.createElement(ImageTable, { images })
                : React.createElement('div', { 
                    style: { 
                        backgroundColor: '#f8fafc', 
                        borderRadius: '6px', 
                        padding: '24px', 
                        textAlign: 'center',
                        marginTop: '16px'
                    } 
                },
                    React.createElement('div', { 
                        style: { 
                            fontSize: '0.9rem', 
                            color: '#64748b', 
                            marginBottom: '8px' 
                        } 
                    }, 'No images found on this page.'),
                    React.createElement('div', { 
                        style: { 
                            fontSize: '0.8rem', 
                            color: '#94a3b8' 
                        } 
                    }, 'Images are important for user engagement and SEO.')
                )
        )
    );
});